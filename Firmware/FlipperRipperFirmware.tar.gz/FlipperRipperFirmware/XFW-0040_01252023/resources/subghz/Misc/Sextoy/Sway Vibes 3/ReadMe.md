# Sway Vibes No. 3

Vibrating panties with remote

![Sway_Vibes_3](https://user-images.githubusercontent.com/57457139/194739791-ed1b4362-10e7-4d05-9aeb-2828ac6a7b68.jpg)
